# Made in Japan ブランドメッセージ

呼び出し名：**皇統のMade in Japanの文言**

## 日本語

> 世界最古の皇統を受け継ぐ日本。学び、工夫し、改良を積み重ねる気質が、現代のMade in Japanを育ててきました。

## English

> Japan, home to the world’s oldest continuing imperial line, has cultivated Made in Japan quality through generations of learning, craftsmanship, and continuous improvement.

## 表記上の注意

- 天皇は **Emperor** とし、Kingとは表記しない。
- 「王統」ではなく「皇統」を使用する。
- 商品の品質を皇統だけに直接結び付けず、日本の長い歴史、学び、職人技、継続的な改良の積み重ねとして表現する。
- 公開時は、文章を載せる場所と前後の文脈を最終確認する。
